WEBSITE ANIMASI - SMA PLUS PGRI CIBINONG

Cara menjalankan:
1. Ekstrak folder website_animasi.
2. Buka index.html menggunakan browser.
3. Pastikan internet aktif agar Bootstrap, Bootstrap Icons, Animate.css, dan AOS dapat dimuat dari CDN.

Fitur: navbar responsif, layout Bootstrap 3 kolom, animasi AOS saat scroll, animasi header dan ikon sosial, footer.
